import React, { useState } from 'react'
import './loginpage.css'
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";
import { MDBInput, MDBCheckbox, MDBBtn, MDBIcon } from 'mdb-react-ui-kit';
import {
    MDBCarousel,
    MDBCarouselItem,
} from 'mdb-react-ui-kit';
import { FcGoogle } from "react-icons/fc";


export default function LoginPage() {
    const [logData,setLogData]=useState({
        email:"",
        password:""
    })

    return (
        <>
            <div className="bgContent">
                <div className="header">
                    <div className="bodyMain"  >
                        <div className="bodyForm"  >
                            <div className="caroContent">
                                <MDBCarousel>
                                    <MDBCarouselItem
                                        className='w-100 d-block'
                                        itemId={1}

                                        src='/undraw_Beach_day_cser(1).svg'
                                        alt='...'
                                    >
                                        {/* <h5>First slide label</h5>
                                        <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
                                    </MDBCarouselItem>
                                    <MDBCarouselItem
                                        className='w-100 d-block'
                                        itemId={2}
                                        src='/undraw_Beach_day_cser(1).svg'
                                        alt='...'
                                    >

                                    </MDBCarouselItem>
                                    <MDBCarouselItem
                                        className='w-100 d-block'
                                        itemId={3}
                                        src='/undraw_Beach_day_cser(1).svg'
                                        alt='...'
                                    >

                                    </MDBCarouselItem>
                                </MDBCarousel>
                            </div>
                            <dvi className="textCaroContent">
                                <MDBCarousel showIndicators >
                                    <MDBCarouselItem
                                        className='w-100'
                                        itemId={1}
                                        src='/plain.svg'
                                    >
                                        <h5>First slide label</h5>
                                        <p id='caroSubtext'>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                                    </MDBCarouselItem>
                                    <MDBCarouselItem
                                        className='w-100 d-block'
                                        itemId={2}
                                        src='/plain.svg'
                                        // id="caroCard"
                                    >
                                        <h5>Second slide label</h5>
                                        <p id='caroSubtext'>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                                    </MDBCarouselItem>
                                    <MDBCarouselItem
                                        className='w-100 d-block'
                                        itemId={3}
                                        src='/plain.svg'
                                    >
                                        <h5>Third slide label</h5>
                                        <p id='caroSubtext'>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                                    </MDBCarouselItem>
                                </MDBCarousel>
                            </dvi>

                        </div>
                        <div className="bodyAdd"  >
                            <MDBIcon className='ms-1' fab icon='twitter' size='2x' id='iConMain' />
                            <div id='iConText'>Hello Again!</div>
                            <div id='iConSubText'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi facere.</div>
                            <div className="formcontent">
                                <MDBInput wrapperClass='mb-4' type='email'  label='Email' id='formControlDefault' />
                                <MDBInput wrapperClass='mb-4' type='password' label='Password' id='formControlDefault' />
                                <div className="d-flex justify-content-between mx-4 mb-4" id='ForgData'>
                                    <MDBCheckbox name='flexCheck' value='' id='flexCheckDefault' label='Remember me' />
                                    <a href="!#">Forgot password?</a>
                                </div>
                                <MDBBtn className="mb-2 w-100" size='md'>
                                    Login
                                </MDBBtn>

                                <MDBBtn outline className="text-muted mb-2 w-100" size="md" style={{ borderColor: '#B0B3C4' }}>
                                    {/* <MDBIcon fab icon="google" className="mx-2" color='danger'/> */}
                                    <FcGoogle className="mx-2" size='16px' />
                                    Sign in with google
                                </MDBBtn>
                                <div className='text-center ' id='FootData'>
                                    <p>
                                        Dont have an account yet? <a href='#!'>Sign UP</a>
                                    </p>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </>
    )
}
